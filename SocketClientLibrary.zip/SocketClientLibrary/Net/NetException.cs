﻿using System;


namespace RTDMes.Forms.SocketClientLibrary.Net
{
    /// <summary>
    /// 网络异常类
    /// </summary>
    public class NetException : Exception
    {
        public NetException(string message)
            : base(message)
        {
        }
    }
}
