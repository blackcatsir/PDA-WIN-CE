﻿using System.Threading;
using RTDMes.Forms.SocketClientLibrary.Net.Tcp;

namespace RTDMes.Forms.SocketClientLibrary.Net
{
    /// <summary>
    /// 调试工具
    /// </summary>
    public static class NetDebuger
    {
        public static void PrintDebugMessage(string message)
        {
            
        }

        static Mutex sync = new Mutex();

        public static void PrintDebugMessage(TcpSession session, string message)
        {
            
        }

        public static void PrintErrorMessage(TcpSession session, string message)
        {
            

        }

        public static void PrintErrorMessage(string message)
        {

        }

    }
}
