﻿using Messages;
using RTDMes.Forms.SocketClientLibrary.Net;
using System;

namespace RTDMes.SocketClientLibrary
{
    public class SocketServiceProxy
    {
        private static MessageBlockClient _client = new MessageBlockClient();

        private static SocketServiceProxy _socketServiceProxy = null;

        private string _dllName;
        private string _className;

        private DataBlock blockSend = new DataBlock(1024 * 5);

        private SocketServiceProxy() { }

        private SocketServiceProxy(string dllName, string className)
        {
            this._dllName = dllName;
            this._className = className;
        }

        public static SocketServiceProxy CreateInstance(string hostIP, int port, string dllName, string className)
        {
            if (_socketServiceProxy == null)
            {
                _socketServiceProxy = new SocketServiceProxy(dllName, className);
                _client.Host = hostIP;
                _client.Port = port;
                _client.EnableCheckHeartBeat = false;
                _client.Start();
            }

            return _socketServiceProxy;
        }

        public void Start()
        {
            if (_client.IsConnected)
                _client.Start();
        }

        public void Stop()
        {
            _client.Stop();
        }

        ~SocketServiceProxy()
        {
            _client.Stop();
            _client.Dispose();
        }

        public object Invoke(string funName, params object[] Args)
        {
            try
            {
                Messages.Message message = new Messages.Message(this._dllName, this._className, funName, Args);

                byte[] buffer = BinaryConverter.ChangeObjectToByte(message);

                blockSend.Reset();

                if (buffer.Length > blockSend.Length)
                {
                    blockSend.Resize(buffer.Length + 1);
                }

                blockSend.Add(buffer, 0, buffer.Length);

                byte[] buffer2 = _client.Invoke(blockSend);

                return BinaryConverter.ChangeByteToObject(buffer2);
            }
            catch
            {
                throw new NetException("网络故障，请重试！");
            }
        }
    }
}
