﻿using System;
using System.Threading;
using RTDMes.Forms.SocketClientLibrary.Net;
using RTDMes.Forms.SocketClientLibrary.Net.Tcp;
using RTDMes.Forms;
using RTDMes.PDAService;
namespace RTDMes.SocketClientLibrary
{
    public class MessageBlockClient : MessageBlockClient<MessageBlockSession>
    {
        public MessageBlockClient()
        {
            this.EnableCheckHeartBeat = false;
        }

        ~MessageBlockClient()
        {
            this.Stop();
        }

        private bool isOnLine = true;
        private byte[] Buffer;
        private object monitorObject = new object();
        internal int reqTimeout = 10000;
        private AutoResetEvent autoRetEvent = new AutoResetEvent(false);

        public byte[] Invoke(DataBlock data)
        {
            try
            {
                Monitor.Enter(monitorObject);

                // 如果已经是断线状态，则重新连接
                if (!isOnLine)
                {
                    this.Stop();
                    this.Start();
                    isOnLine = true;
                }

                autoRetEvent.Reset();
                Send(data);

                if (!autoRetEvent.WaitOne(reqTimeout, false))
                {
                    // 如果执行超时，重新连接
                    this.Stop();
 
                    this.Start();
                    // 重送一次
                    Send(data);
                   
                    if (!autoRetEvent.WaitOne(reqTimeout, false))
                    {
                        // 如果仍然超时，则标记掉线状态
                        isOnLine = false;
                        Buffer = null;
                    }
                }

                Monitor.Exit(monitorObject);

              
            }
            catch (Exception ex)
            {

                throw ex;
               
            }
            if (Buffer == null)
                throw new Exception("连接超时，请重新操作！");
            
            return Buffer;
        }

        protected override void OnConnectServer()
        {
            isOnLine = true;
        }

        protected override void OnReceivedMessageBlock(MessageBlock mb)
        {
            // 屏蔽网络故障引起的接收异常
            try
            {
                Buffer = mb.Body.ToArray();
            }
            catch 
            {
                Buffer = null;
                isOnLine = false;
            }
            finally
            {
                autoRetEvent.Set();
            }
        }

        protected override void OnConnectServerFail(Exception e)
        {
            isOnLine = false;

            autoRetEvent.Set();
        }

        protected override void OnError(Exception e)
        {
            isOnLine = false;

            autoRetEvent.Set();
        }

        protected override void OnDropLine()
        {
            isOnLine = false;

            autoRetEvent.Set();
        }
    }
}
